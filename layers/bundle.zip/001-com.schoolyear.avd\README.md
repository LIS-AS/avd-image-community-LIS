# Schoolyear base layer

This layer is built-in and prepares the Schoolyear base image.
It should be included in every image used with Schoolyear AVD.
The AVD CLI includes this layer in every bundle by default.
